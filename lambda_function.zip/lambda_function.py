import boto3
import os

def lambda_handler(event, context):
    # Get all EC2 instances
    ec2 = boto3.client('ec2')
    instances = ec2.describe_instances()
    instance_names = []

    for reservation in instances['Reservations']:
        for instance in reservation['Instances']:
            instance_id = instance['InstanceId']
            instance_name = [tag['Value'] for tag in instance.get('Tags', []) if tag['Key'] == 'Name']
            if instance_name:
                instance_names.append(instance_name[0])
            # Stop the instance
            ec2.stop_instances(InstanceIds=[instance_id])

    custom_message = "The EC2 instance of Abdullah's account has been stopped."

    # Construct the message with your custom message and a list of stopped instances
    message = f"{custom_message}\nEC2 Instances Stopped: {', '.join(instance_names)}"

    # Publish the message to an SNS topic
    sns = boto3.client('sns')
    sns_topic_arn = os.environ['SNS_TOPIC_ARN']
    sns.publish(TopicArn=sns_topic_arn, Message=message)
